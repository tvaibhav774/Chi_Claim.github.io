async function loadClaims() {
  const res = await fetch('/api/claims');
  const data = await res.json();
  const tbody = document.getElementById('claims-table-body');
  tbody.innerHTML = '';
  data.forEach(c => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${c.id}</td><td>${c.claimDate}</td><td>${c.amount}</td><td>${c.status}</td>
      <td>
        <button onclick="downloadPDF('${c.id}')">PDF</button>
        ${c.status==='Pending Manager'
            ? `<button onclick="approveManager('${c.id}')">Approve (Mgr)</button>`
            : ''}
        ${c.status==='Pending HR'
            ? `<button onclick="approveHR('${c.id}')">Approve (HR)</button>`
            : ''}
      </td>`;
    tbody.append(row);
  });
}

async function downloadPDF(id) {
  window.location = `/api/claims/${id}/pdf`;
}
async function approveManager(id) {
  await fetch(`/api/claims/${id}/approve/manager`, { method: 'POST' });
  loadClaims();
}
async function approveHR(id) {
  await fetch(`/api/claims/${id}/approve/hr`, { method: 'POST' });
  loadClaims();
}
async function exportAllPDF() {
  window.location = '/api/claims/export';
}

const express = require('express');
const bodyParser = require('body-parser');
const pdfUtils = require('./pdfUtils');
const app = express();
app.use(bodyParser.json());

let claims = [];

// Submit new claim
app.post('/api/claims', (req, res) => {
  const id = 'C' + Date.now();
  const record = {
    id, ...req.body,
    status: 'Pending Manager',
    submittedAt: new Date()
  };
  claims.push(record);
  res.json({ success: true, id });
});

// Get all claims
app.get('/api/claims', (req, res) => res.json(claims));

// Approve (manager)
app.post('/api/claims/:id/approve/manager', (req, res) => {
  const c = claims.find(c => c.id === req.params.id);
  if (!c) return res.status(404).end();
  if (c.status === 'Pending Manager') c.status = 'Pending HR';
  res.json(c);
});

// Final Approval by HR
app.post('/api/claims/:id/approve/hr', (req, res) => {
  const c = claims.find(c => c.id === req.params.id);
  if (!c) return res.status(404).end();
  if (c.status === 'Pending HR') c.status = 'Approved';
  res.json(c);
});

// Download PDF for single claim
app.get('/api/claims/:id/pdf', async (req, res) => {
  const c = claims.find(c => c.id === req.params.id);
  if (!c) return res.status(404).end();
  const buffer = await pdfUtils.generateClaimPDF(c);
  res
    .set('Content-Type', 'application/pdf')
    .set('Content-Disposition', `attachment; filename="${c.id}.pdf"`)
    .send(buffer);
});

// Download all claims as Excel or PDF (Excel export not implemented)
app.get('/api/claims/export', async (req, res) => {
  // Example: export PDF containing all claims
  const buffer = await pdfUtils.generateAllClaimsPDF(claims);
  res
    .set('Content-Type', 'application/pdf')
    .set('Content-Disposition', 'attachment; filename="all_claims.pdf"')
    .send(buffer);
});

app.listen(3000, () => console.log('Server running on port 3000'));



let users = [];

// Create a new user (Manager access assumed)
app.post('/api/users', (req, res) => {
  const { id, name, role } = req.body;
  if (!id || !name || !role) return res.status(400).json({ success: false, error: 'Missing fields' });
  users.push({ id, name, role });
  res.json({ success: true, message: 'User created' });
});


const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const userFilePath = path.join(__dirname, 'users.json');

if (fs.existsSync(userFilePath)) {
  users = JSON.parse(fs.readFileSync(userFilePath, 'utf8'));
}

function saveUsersToFile() {
  fs.writeFileSync(userFilePath, JSON.stringify(users, null, 2));
}

// Create user with hashed password
app.post('/api/users', async (req, res) => {
  const { id, name, role, password } = req.body;
  if (!id || !name || !role || !password) return res.status(400).json({ success: false, error: 'Missing fields' });
  if (users.find(u => u.id === id)) return res.status(400).json({ success: false, error: 'User ID already exists' });
  const hashed = await bcrypt.hash(password, 10);
  const user = { id, name, role, password: hashed };
  users.push(user);
  saveUsersToFile();
  res.json({ success: true, message: 'User created', user: { id, name, role } });
});

// Login route
app.post('/api/login', async (req, res) => {
  const { id, password } = req.body;
  const user = users.find(u => u.id === id);
  if (!user) return res.status(401).json({ success: false, error: 'Invalid ID or password' });
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ success: false, error: 'Invalid ID or password' });
  res.json({ success: true, message: 'Login successful', user: { id: user.id, name: user.name, role: user.role } });
});


const session = require('express-session');
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false
}));

// Middleware to check if user is logged in
function requireLogin(req, res, next) {
  if (req.session.user) next();
  else res.status(401).json({ success: false, error: 'Not logged in' });
}

// Middleware to check manager role
function requireHR(req, res, next) {
  if (req.session.user?.role === 'hr') next();
  else res.status(403).json({ success: false, error: 'HR access required' });
}

function requireManager(req, res, next) {
  if (req.session.user?.role === 'manager') next();
  else res.status(403).json({ success: false, error: 'Manager access required' });
}

// Update login to set session
app.post('/api/login', async (req, res) => {
  const { id, password } = req.body;
  const user = users.find(u => u.id === id);
  if (!user) return res.status(401).json({ success: false, error: 'Invalid ID or password' });
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ success: false, error: 'Invalid ID or password' });
  req.session.user = { id: user.id, name: user.name, role: user.role };
  res.json({ success: true, message: 'Login successful', user: req.session.user });
});

// Logout route
app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true, message: 'Logged out' }));
});

// Restrict user creation to manager
app.post('/api/users', requireLogin, requireHR, async (req, res) => {
  const { id, name, role, password } = req.body;
  if (!id || !name || !role || !password) return res.status(400).json({ success: false, error: 'Missing fields' });
  if (users.find(u => u.id === id)) return res.status(400).json({ success: false, error: 'User ID already exists' });
  const hashed = await bcrypt.hash(password, 10);
  const user = { id, name, role, password: hashed };
  users.push(user);
  saveUsersToFile();
  res.json({ success: true, message: 'User created', user: { id, name, role } });
});


// Claims persistence setup
const claimsPath = path.join(__dirname, 'claims.json');
let claims = fs.existsSync(claimsPath) ? JSON.parse(fs.readFileSync(claimsPath, 'utf8')) : [];

function saveClaimsToFile() {
  fs.writeFileSync(claimsPath, JSON.stringify(claims, null, 2));
}

// Override existing claims API logic with file persistence

// Submit new claim
app.post('/api/claims', requireLogin, (req, res) => {
  const id = 'C' + Date.now();
  const record = {
    id, ...req.body,
    status: 'Pending Manager',
    submittedAt: new Date()
  };
  claims.push(record);
  saveClaimsToFile();
  res.json({ success: true, id });
});

// Get all claims
app.get('/api/claims', requireLogin, (req, res) => res.json(claims));

// Approve (manager)
app.post('/api/claims/:id/approve/manager', requireLogin, requireManager, (req, res) => {
  const c = claims.find(c => c.id === req.params.id);
  if (!c) return res.status(404).end();
  if (c.status === 'Pending Manager') {
    c.status = 'Pending HR';
    saveClaimsToFile();
  }
  res.json(c);
});

// Final Approval by HR
app.post('/api/claims/:id/approve/hr', requireLogin, (req, res) => {
  const c = claims.find(c => c.id === req.params.id);
  if (!c) return res.status(404).end();
  if (c.status === 'Pending HR' && req.session.user?.role === 'hr') {
    c.status = 'Approved';
    saveClaimsToFile();
  }
  res.json(c);
});


// Get list of all users (Manager only, no passwords)
app.get('/api/users', requireLogin, requireHR, (req, res) => {
  const safeUsers = users.map(u => ({ id: u.id, name: u.name, role: u.role }));
  res.json(safeUsers);
});

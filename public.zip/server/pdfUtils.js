const PdfPrinter = require('pdfmake');
const fonts = {
  Roboto: {
    normal: 'fonts/Roboto-Regular.ttf',
    bold: 'fonts/Roboto-Medium.ttf',
  }
};
const printer = new PdfPrinter(fonts);

function claimDocDefinition(c) {
  return {
    content: [
      { text: `Claim ID: ${c.id}`, style: 'header' },
      { text: `Employee ID: ${c.employeeId}` },
      { text: `Date: ${c.claimDate}` },
      { text: `Period: ${c.periodFrom} to ${c.periodTo}` },
      { text: `Expense Type: ${c.expenseType}` },
      { text: `Project Code: ${c.projectCode}` },
      { text: `Amount: ₹${c.amount}` },
      { text: `Status: ${c.status}` },
    ],
    styles: {
      header: { fontSize: 18, bold: true, margin: [0,0,0,10] }
    }
  };
}

async function generateClaimPDF(c) {
  const doc = printer.createPdfKitDocument(claimDocDefinition(c));
  const chunks=[];
  return new Promise(resolve => {
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.end();
  });
}

async function generateAllClaimsPDF(all) {
  const body = [
    ['ID', 'Date', 'Employee', 'Amount', 'Status'],
    ...all.map(c => [c.id, c.claimDate, c.employeeId, c.amount.toString(), c.status])
  ];
  const docDef = {
    content: [{ text: 'All Claims', style: 'header' },
      { table: { headerRows:1, widths: ['*','*','*','*','*'], body } }
    ],
    styles: { header: { fontSize: 20, bold: true, margin: [0,0,0,15] } }
  };
  const doc = printer.createPdfKitDocument(docDef);
  const chunks = [];
  return new Promise(resolve=>{
    doc.on('data', ch=>chunks.push(ch));
    doc.on('end', ()=>resolve(Buffer.concat(chunks)));
    doc.end();
  });
}

module.exports = { generateClaimPDF, generateAllClaimsPDF };
